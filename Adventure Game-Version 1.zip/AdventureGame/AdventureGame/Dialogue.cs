﻿using System;
namespace AdventureGame
{
    public class Dialogue
    {
        public Dialogue()
        {
        }
    }
}
