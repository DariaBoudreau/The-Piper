﻿using System;
namespace AdventureGame
{
    public class Item
    {
        public Item()
        {
        }
    }
}
