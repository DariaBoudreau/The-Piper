﻿using System;
using System.Collections.Generic;
using System.IO;
using static System.Console;
namespace AdventureGame
{
    public class Game
    {
        public string GameTitle = "The Piper";
        public string TitleArt = @" _________  __              _______   _                          
|  _   _  |[  |            |_   __ \ (_)                         
|_/ | | \_| | |--.  .---.    | |__) |__  _ .--.   .---.  _ .--.  
    | |     | .-. |/ /__\\   |  ___/[  |[ '/'`\ \/ /__\\[ `/'`\] 
   _| |_    | | | || \__.,  _| |_    | | | \__/ || \__., | |     
  |_____|  [___]|__]'.__.' |_____|  [___]| ;.__/  '.__.'[___]    
                                        [__|                     ";


        public void Play()
        {
            DisplayIntro();
            StartGame();
            DisplayOutro();
        }


        public void DisplayIntro()
        {
            BackgroundColor = ConsoleColor.DarkBlue;
            ForegroundColor = ConsoleColor.White;
            WriteLine($"{TitleArt}");
            BackgroundColor = ConsoleColor.Black;
            WriteLine("========================================");
            WriteLine(@"The year is 1997. You are Taylor, a 17 year old just trying to make it through
high school with your girlfriend, Avery, and best friend, Ellis.You all live normal,
boring lives until someone, or something, starts causing people in your town to vanish…");
            WriteLine("========================================");
            ResetColor();
        }


        public void StartGame()
        {
            WriteLine(@"It’s a cool, autumn day, and you’ve just gotten home from school. It was
pretty uneventful, with the only thing out of the ordinary being that Ellis didn’t
show up for school today. You figured he had probably skipped, which was a pretty
common occurrence with him. You were just about to take off your backpack and flop
onto bed when a familiar alert chime comes from your computer.");

            Write(@"You go to your desk to check the screen. You have several new messages,
some from Avery, and some from Ellis. Whose messages do you view? ");

            WhichMessage();
        

        }


        public void WhichMessage()
        {
            string playerAnswer = ReadLine().ToLower().Trim();
            if (playerAnswer == "avery")
            {
                BackgroundColor = ConsoleColor.DarkBlue;
                WriteLine("You open up Avery's message.");
                ResetColor();
            }
            else if (playerAnswer == "ellis")
            {
                BackgroundColor = ConsoleColor.DarkBlue;
                WriteLine("You open up Ellis' message.");
                ResetColor();
            }
            else
            {
                BackgroundColor = ConsoleColor.DarkBlue;
                WriteLine("Invalid response. Please choose 'Avery' or 'Ellis'");
                ResetColor();
                WhichMessage();
            }

        }


        public void DisplayOutro()
        {
            BackgroundColor = ConsoleColor.Black;
            ForegroundColor = ConsoleColor.White;
            WriteLine("========================================");
            WriteLine(@"Thanks for playing The Piper.
Game concept and programming by Daria Boudreau, 2020.");
            WriteLine("========================================");
        }



    }
}
