﻿using System;
namespace AdventureGame
{
    public class Item
    {
        //this will track whether or not supplies and clues are picked up

        //bool isPickedUp = false;

        public Item()
        {
        }
    }
}
