﻿using System;
using System.Collections.Generic;
using System.IO;
using static System.Console;
namespace AdventureGame
{
    public class Game
    {
        public string GameTitle = "The Piper";


        //Contains everything that will run when the application opens
        public void Play()
        {
            RunMainMenu();
            StartGame();
            DisplayOutro();
        }

        //displays main menu screen
        private void RunMainMenu()
        {
            ForegroundColor = ConsoleColor.White;
            BackgroundColor = ConsoleColor.DarkBlue;
            string prompt = @"
_________  __              _______   _                          
|  _   _  |[  |            |_   __ \ (_)                         
|_/ | | \_| | |--.  .---.    | |__) |__  _ .--.   .---.  _ .--.  
    | |     | .-. |/ /__\\   |  ___/[  |[ '/'`\ \/ /__\\[ `/'`\] 
   _| |_    | | | || \__.,  _| |_    | | | \__/ || \__., | |     
  |_____|  [___]|__]'.__.' |_____|  [___]| ;.__/  '.__.'[___]    
                                        [__|

                                   .     _,
                                   |`\__/ /
                                   \  . .(
                                    | __T|
                                   /   |
                      _.---======='    |
=================    //               {}  ====================
                    `|      ,   ,     {}
                     \      /___;    ,'
                      ) ,-;`    `\  //
                     | / (        ;||
                     ||`\\        |||
                     ||  \\       |||
                     )\   )\      )||
                     `''   ''      `''

(Use the arrow keys to cycle through options and press 'enter' to select)";

            ResetColor();
            string[] options = { "Play", "Credits", "Exit", };
            Menu mainMenu = new Menu(prompt, options);
            int selectedIndex = mainMenu.Run();

            switch (selectedIndex)
            {
                case 0:
                    StartGame();
                    break;
                case 1:
                    DisplayCredits();
                    break;
                case 2:
                    ExitGame();
                    break;
            }
        }


        private void ExitGame()
        {
            WriteLine("\nPress any key to exit...");
            ReadKey(true);
            Environment.Exit(0);
        }

        private void DisplayCredits()
        {
            WriteLine("Based upon the story of 'The Piper' written by Daria Boudreau");
            WriteLine("Game concept and programming by Daria Boudreau");
            WriteLine("Fonts from http://patorjk.com/software/taag");
            WriteLine("Art from https://www.asciiart.eu/animals/deer");
            WriteLine("Created for Intro to Programming, 2020");
            WriteLine("Press any key to return to the main menu.");
            ReadKey(true);
            RunMainMenu();
        }


        //Starts up the game
        public void StartGame()
        {
            WriteLine("\n========================================");
            ForegroundColor = ConsoleColor.White;
            BackgroundColor = ConsoleColor.Black;
            WriteLine(@"The year is 1997. You are Taylor, a 17 year old just trying to make it through
high school with your girlfriend, Avery, and best friend, Ellis. You all live normal,
boring lives until someone, or something, starts causing people in your town to vanish…");
            ResetColor();

            WriteLine("========================================");

            WriteLine(@"It’s a cool, autumn day, and you’ve just gotten home from school. It was
pretty uneventful, with the only thing out of the ordinary being that Ellis didn’t
show up for school today. You figured he had probably skipped, which was a pretty
common occurrence with him. You were just about to take off your backpack and flop
onto bed when a familiar alert chime comes from your computer. You go to your desk to check the screen.
You have several new messages,some from Avery, and some from Ellis.

(press enter to continue)
");

            ReadLine();

            FirstChoice();

        }




        //ALL CHOICES GO DOWN HERE:


        //Taylor gets home from school and gets messages alerting her Stacey is missing
        public void FirstChoice()
        {
            string prompt = @"Whose messages do you view?";
            string[] options = { "Avery", "Ellis" };
            Menu firstMenu = new Menu(prompt, options);
            int selectedIndex = firstMenu.Run();

            switch (selectedIndex)
            {
                case 0:
                    //need to add in colors to differentiate who's sending each message
                    WriteLine(@"You open up Avery's message. Or rather, a string of several messages.
[3:40pm] AVERYxFOSTER: wonder where the hell ellis was today, he usually tells me if he skips
[3:40pm] AVERYxFOSTER: he better be getting more weed for the weekend :))))
[3:41pm] AVERYxFOSTER: im gonna message him it says hes online
[3:52pm] AVERYxFOSTER: holy shit
[3:52pm] AVERYxFOSTER: taylor youve gotta answer his message RIGHT NOW
[3:53pm] AVERYxFOSTER: if you dont answer im calling your house

You hastily respond back.
[3:53pm] Taylor_Patterson: what happened??is everything okay??

[3:53pm] AVERYxFOSTER: just read his message

(press enter to continue)
");
                    ReadLine();
                    FirstChoice();
                    break;

                case 1:
                    WriteLine(@"You open up Ellis' messages.
[3:27pm] ellisthewatson: dude.
[3:27pm] ellisthewatson: stacey is jsut gone
[3:27pm] ellisthewatson: weve been looking all day and were freaking tf out my mom just made missing persosn report
[3:30pm] ellisthewatson: please answer me

Shock settles in as your heart drops. The whole town had been on alert since three kids went missing over the course of only a few months.
And now Ellis' little sister was the fourth.
[3:53pm] Taylor_Patterson: oh my god im so sorry i just got back from school
[3:54pm] Taylor_Patterson: wtf happened????
[3:54pm] ellisthewatson: we dont know but the cops are already setting up a search party they dont want to waste any time
[3:54pm] ellisthewatson: can you please come i need you here
[3:54pm] ellisthewatson: and avery too if she can i already told her whats going on
[3:54pm] Taylor_Patterson: of course im leaving right now
[3:54pm] ellisthewatson: ok im sending you address

You shoot a message to Avery, telling her that you're coming to pick her up.
You hastily shut down the computer and grab your backpack once more, nearly flying down the stairs before getting in your car and racing away.

(press enter to continue)
");
                    ReadLine();
                    SecondChoice();
                    break;
            }
        }


        // taylor and avery reach the meetup spot for the search party
        public void SecondChoice()
        {
            WriteLine(@"The sky is already getting dark. You can’t tell if there’s electricity growing in the air,
indicating an oncoming storm, or if you’re just imagining things.
You pull into a small parking lot with a sign that reads ‘BRUNSWICK PROVINCIAL PARK’.

Dozens of people are milling around the entrance to the trails. Folding tables have been set up, covered with water bottles, walkie-talkies,
and large stacks of missing posters. They already have new ones printed out with Stacey’s face on them, laying alongside the other kids’ faces.

A few police officers stand nearby, one with arms crossed and another scribbling in a notepad as they talk with a trembling teenage girl who
appears to be Stacey’s friend. You soon spot Ellis, who seems to be in deep conversation with his mother. Mrs. Watson has her arms tightly wrapped
around herself. You can tell she’s been crying recently. Upon noticing you, Ellis slips away and walks over.
‘We’ll be heading out in a few minutes,’ he says. His voice is completely hollow, his face impassive.

'So this is where she was last seen?' you say.

'No, the last place I saw her was my house. But she apparently she snuck out last night to go out with her friend.
They were supposed to meet here, but the friend said she never showed up,' he explains.

'Why here?'

'It's huge and it's in the middle of nowhere. Good place to go if you don't want to be caught. And when I checked this morning, part of my
stash was taken, so I think I have an idea what she was going out there to do.'

'God. She's only what, a freshman this year?' Avery pipes up.

'Does that even matter right now?' Ellis snaps. 'I can yell at her for stealing my weed after I find her.'

You look around. People have already started getting into small groups and are heading into the woods. 

(press enter to continue)
");
            ReadLine();

            Item suppliesItem = new Item();
            string prompt = @"You are eager to get going, and Ellis obviously is too, considering every second counts.
But you don't want to head in unprepared, either. What do you do?";
            string[] options = { "Start searching right away", "Stay and look around" };
            Menu secondMenu = new Menu(prompt, options);
            int selectedIndex = secondMenu.Run();

            switch (selectedIndex)
            {
                case 0:
                    WriteLine("You head into the woods.");
                    //add more text here
                    //if the player makes this choice, no supplies are taken
                    ReadLine();
                    //ThirdChoice();
                    break;

                case 1:
                    WriteLine("You stay and look around.");
                    //add more text here
                    //if the player makes this choice, they will be able to pick up supplies (flashlight and map)
                    //return isPickedUp bool as true
                    ReadLine();
                    //ThirdChoice();
                    break;
            }
        }


            //choose which path to go down
            public void ThirdChoice()
         {
            //WriteLine("Introduction text");
            // if supplies isPickedUp = true, additional text will appear telling them what path to go down because they have a map,
            // and having the flashlight allows them to find the clues there
            
            //string prompt = @"What do you do?";
            //string[] options = { "Left path", "Right path" };
            //Menu secondMenu = new Menu(prompt, options);
            //int selectedIndex = secondMenu.Run();

            //switch (selectedIndex)
            {
                //case 0:
                    //WriteLine("You head down the left path.");
                    //ReadLine();
                    //FourthChoice();
                    //break;

                //case 1:
                    //WriteLine("You head down the right path.");
                    //ReadLine();
                    //FourthChoice();
                    //break;
            }
        }

        //choose to run or hide
        public void FourthChoice()
        {
            //WriteLine("Introduction text");

            //string prompt = @"What do you do?";
            //string[] options = { "Run", "Hide" };
            //Menu fourthMenu = new Menu(prompt, options);
            //int selectedIndex = fourthMenu.Run();

            //switch (selectedIndex)
            {
                //case 0:
                //WriteLine("You run.");
                //ReadLine();
                //GameEnding1();
                //break;

                //case 1:
                //WriteLine("You hide.");
                //ReadLine();
                //GameEnding2();
                //break;
            }
        }


        public void DisplayOutro()
            {
                BackgroundColor = ConsoleColor.Black;
                ForegroundColor = ConsoleColor.White;
                WriteLine("========================================");
                WriteLine(@"Thanks for playing The Piper.
Game concept and programming by Daria Boudreau, 2020.");
                WriteLine("========================================");
            }



        }
    }

